 <section class="news-area section-padding">
<div class="container mt-5 mb-5">





    <div class="row">
	

	
    <div class="col-lg-12">
	
	<h3> <?php echo  $homeMidHeadOne;?> </h3>
	
	
	<p id="paragrafi"><?php echo  $homeMidContentOne;?> </p>

	
	</div>
	
	
	<div class="col-lg-6">
	
	<h3> <?php echo  $homeMidHeadTwo;?> </h3>
	
	
	
	<p id="paragrafi"><?php echo $homeMidContentTwo ; ?> </p>
	
	
	</div>
	
	<div class="col-lg-6">
	
	
		<h3> <?php echo  $homeMidHeadThree;?> </h3>
		
			<p id="paragrafi"><?php echo $homeMidContentThree ; ?> </p>
	
	
	</div>
	
	
   
    </div>





	
	
	

   
</div>
    </section>