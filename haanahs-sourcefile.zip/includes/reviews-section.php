 <section class="news-area section-padding">
<div class="container mt-5 mb-5">


    
    <div class="row g-2">
       <script src="https://apps.elfsight.com/p/platform.js" defer></script>
<div class="elfsight-app-1efe31ce-40e1-45d5-9290-39025b95cabf"></div>
        
        
    </div>
    
</div>
    </section>