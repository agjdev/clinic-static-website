    <section class="banner-area other-page">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1><?php echo $headOne;?></h1>
                    <a href="<?php echo $homeurl;?>" class="text-dark">Hannah's Clinic</a> <span>|</span> <a href="<?php echo $curr_url;?>" class="text-dark"><?php echo $curr_page;?></a>
                </div>
            </div>
        </div>
    </section>
    <!-- Banner Area End -->