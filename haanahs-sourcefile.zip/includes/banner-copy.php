   <section class="banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <h4><?php echo $homeTagline;?></h4>
                    <h1><?php echo $homeMainHeading;?></h1>
                    <p><?php echo $homeQuote;?></p>
                    <a href="contact-us.php"  class="btn btn-outline-success mt-3"><i class="fa fa-calendar" aria-hidden="true"></i> Make An Appointment</a>
                </div>
            </div>
        </div>
    </section>