    <!-- Hotline Area Starts -->
    <section class="hotline-area text-center section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>Dial Us On </h2>
                    <span>(+91) – 7338206497 </span>
                    <p class="pt-3">We love to assist you always. Please feel free to contact us .</p>
                </div>
            </div>
        </div>
    </section>
    <!-- Hotline Area End -->